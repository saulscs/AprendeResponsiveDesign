A Pen created at CodePen.io. You can find this one at http://codepen.io/jonmircha/pen/yNqvVq.

 For small screens a “menu” button appears that, when clicked, expands an accordion style navigation. When more screen real estate becomes available

Forked from [Brad Frost](http://codepen.io/bradfrost/)'s Pen [Toggle Navigation](http://codepen.io/bradfrost/pen/sHvaz/).